<?php 
	mysql_connect("localhost","root","") or die("Couldn't connet to SQL server");
	mysql_select_db("pmsdb") or die("Couldn'ttt select DB");
?>