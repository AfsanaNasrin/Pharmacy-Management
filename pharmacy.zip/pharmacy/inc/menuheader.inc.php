<div class="categolis">
		<table>
			<tr>
				<th>
					<a href="syrup.php" style="text-decoration: none;color: #fff;padding: 4px 12px;background-color: #24bfae;border-radius: 12px;">Syrups</a>
				</th>
				
				<th><a href="syrup.php" style="text-decoration: none;color: #ddd;padding: 4px 12px;background-color: #c7587e;border-radius: 12px;">Teblets</a></th>
				<th><a href="syrup.php" style="text-decoration: none;color: #ddd;padding: 4px 12px;background-color: #c7587e;border-radius: 12px;">Capsules</a></th>
				<th><a href="syrup.php" style="text-decoration: none;color: #ddd;padding: 4px 12px;background-color: #c7587e;border-radius: 12px;">Peds</a></th>
				<th><a href="syrup.php" style="text-decoration: none;color: #ddd;padding: 4px 12px;background-color: #c7587e;border-radius: 12px;">Drypers</a></th>
				<th><a href="syrup.php" style="text-decoration: none;color: #ddd;padding: 4px 12px;background-color: #c7587e;border-radius: 12px;">Healts Tips</a></th>
			    <th><a href="syrup.php" style="text-decoration: none;color: #ddd;padding: 4px 12px;background-color: #c7587e;border-radius: 12px;">Any needs</a></th>
				<th><a href="syrup.php" style="text-decoration: none;color: #ddd;padding: 4px 12px;background-color: #c7587e;border-radius: 12px;">Others</a></th>
			</tr>
		</table>
	</div>