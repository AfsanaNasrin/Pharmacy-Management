-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2019 at 10:59 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `firstName` varchar(125) NOT NULL,
  `lastName` varchar(125) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(25) NOT NULL,
  `address` text NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `confirmCode` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `firstName`, `lastName`, `email`, `mobile`, `address`, `password`, `type`, `confirmCode`) VALUES
(3, 'Afsana', 'Nasrin', 'afsana@gmail.com', '01678293748', 'Dhaka, Bangladesh', '98427fd4fe1dd535d4492e05f3a25236', 'pharmacist', '117631'),
(4, 'Sima', 'Ahmed', 'sima@gmail.com', '01627021788', 'dhaka,purbo rajabajar', '98427fd4fe1dd535d4492e05f3a25236', 'admin', '956170'),
(6, 'Jia', 'Rahman', 'jia@gmail.com', '01627021788', 'purbo rajabazar,dhaka,92/2', 'e10adc3949ba59abbe56e057f20f883e', 'seller', '121888'),
(7, 'Ria', 'Ali', 'ria@gmail.com', '01627021788', 'dhaka,purbo rajabajar', 'e10adc3949ba59abbe56e057f20f883e', 'seller', '566290'),
(9, 'Simu', 'Ahmed', 'simu@gmail.com', '01627021788', 'rajabazar,jame moshid,92/2', 'e10adc3949ba59abbe56e057f20f883e', 'pharmacist', '389620');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `uid`, `pid`, `quantity`) VALUES
(3, 17, 65, 1),
(12, 18, 65, 1),
(13, 47, 73, 1),
(14, 19, 66, 1),
(15, 0, 67, 1),
(17, 20, 74, 1),
(22, 0, 74, 1),
(23, 0, 68, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `oplace` text NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `dstatus` varchar(10) NOT NULL DEFAULT 'no',
  `delivery` varchar(50) NOT NULL,
  `odate` date NOT NULL,
  `ddate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `uid`, `pid`, `quantity`, `oplace`, `mobile`, `dstatus`, `delivery`, `odate`, `ddate`) VALUES
(47, 14, 66, 2, 'dhaka..road..pue', '01234567897', 'no', 'Express Delivery', '2019-03-26', '0000-00-00'),
(48, 14, 71, 2, 'dhaka..road..pue', '01234567897', 'Yes', 'Express Delivery', '2019-03-26', '2019-04-01'),
(49, 14, 73, 1, 'dhaka..road..pue', '01234567897', 'no', 'Express Delivery', '2019-03-26', '0000-00-00'),
(50, 14, 64, 16, 'dhaka..road..pue', '01234567897', 'no', 'Express Delivery', '2019-03-26', '0000-00-00'),
(51, 14, 73, 5, 'dhaka..road..pue', '01234567897', 'Yes', 'Express Delivery', '2019-03-26', '2019-03-27'),
(52, 14, 68, 9, 'dhaka..road..pue', '01234567897', 'Yes', 'Express Delivery', '2019-03-26', '2019-04-01'),
(53, 14, 66, 3, 'dhaka..road..pue', '01234567897', 'Yes', 'Express Delivery', '2019-03-26', '2019-03-27'),
(54, 14, 67, 1, 'dhaka..road..pue', '01234567897', 'Yes', 'Express Delivery', '2019-03-30', '2019-03-30'),
(55, 14, 65, 1, 'dhaka..road..pue', '01234567897', 'Yes', 'Express Delivery', '2019-03-30', '2019-03-30'),
(56, 14, 73, 10, 'dhaka..road..pue', '01234567897', 'Yes', '', '2019-03-30', '2019-04-01'),
(57, 14, 64, 46, 'dhaka..road..pue', '01234567897', 'Yes', '', '2019-04-04', '2019-04-11'),
(58, 14, 71, 1, 'dhaka..road..pue', '01234567897', 'no', 'Standard Delivery', '2019-04-12', '0000-00-00'),
(59, 14, 66, 1, 'dhaka..road..pue', '01234567897', 'Yes', 'Standard Delivery', '2019-04-12', '2019-04-15'),
(60, 14, 71, 8, 'dhaka..road..pue', '01234567897', 'Yes', '', '2019-04-12', '2019-04-19'),
(61, 21, 66, 1, 'Purborazabazar jame moshjid', '01627021788', 'no', 'Express Delivery', '2019-04-13', '0000-00-00'),
(62, 21, 72, 1, 'Purborazabazar jame moshjid', '01627021788', 'no', 'Express Delivery', '2019-04-13', '0000-00-00'),
(63, 21, 68, 1, 'Purborazabazar jame moshjid', '01627021788', 'no', 'Express Delivery', '2019-04-13', '0000-00-00'),
(64, 21, 64, 1, 'Purborazabazar jame moshjid', '01627021788', 'no', 'Express Delivery', '2019-04-13', '0000-00-00'),
(65, 14, 74, 40, 'dhaka..road..pue', '01234567897', 'Yes', 'Express Delivery', '2019-04-17', '2019-04-20'),
(66, 14, 66, 5, 'dhaka..road..pue', '01234567897', 'no', 'Express Delivery', '2019-04-17', '0000-00-00'),
(67, 14, 67, 9, 'dhaka..road..pue', '01234567897', 'Yes', 'Express Delivery', '2019-04-17', '2019-04-20'),
(68, 25, 66, 1, 'purbo rajabazar,dhaka,92/2', '01627021788', 'no', 'Express Delivery', '2019-04-28', '0000-00-00'),
(69, 25, 65, 3, 'purbo rajabazar,dhaka,92/2', '01627021788', 'no', 'Express Delivery', '2019-04-28', '0000-00-00'),
(70, 14, 66, 3, 'dhaka..road..pue', '01234567897', 'no', 'Express Delivery', '2019-04-28', '0000-00-00'),
(71, 14, 74, 4, 'dhaka..road..pue', '01234567897', 'no', 'Express Delivery', '2019-04-28', '0000-00-00'),
(72, 14, 72, 5, 'dhaka..road..pue', '01234567897', 'no', 'Express Delivery', '2019-04-28', '0000-00-00'),
(73, 26, 66, 6, 'purbo rajabazar,dhaka,92/2', '01627021788', 'no', 'Express Delivery', '2019-04-29', '0000-00-00'),
(74, 26, 65, 77, 'purbo rajabazar,dhaka,92/2', '01627021788', 'Yes', 'Express Delivery', '2019-04-29', '2019-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `pName` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `description` text NOT NULL,
  `available` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `item` varchar(100) NOT NULL,
  `pCode` varchar(20) NOT NULL,
  `picture` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `pName`, `price`, `description`, `available`, `category`, `type`, `item`, `pCode`, `picture`) VALUES
(58, 'eye drop', 90, 'for eye', 9, 'medicine', '', 'syrup', '0014', '1552374473.jpg'),
(59, 'Cloramin', 21, 'allergies, the common cold, or the flu', 5, 'medicine', '', 'syrup', '0013', '1552374562.jpg'),
(60, 'Gestroo', 50, 'For gestrict', 6, 'medicine', '', 'syrup', '0012', '1552374652.jpg'),
(61, 'Ace Paracetamol', 21, 'For Fever', 6, 'paracetamol', '', 'syrup', '0011', '1552374694.jpg'),
(62, 'Gestroo3', 90, 'allergies, the common cold, or the flu', 5, 'medicine', '', 'syrup', '0014', '1552389815.jpg'),
(63, 'eye drop', 90, 'allergies, the common cold, or the flu', 5, 'syrup', '', 'syrup', '0012', '1552390316.jpg'),
(64, 'Cloramin', 90, 'for eye', 50, 'paracetamol', '', 'syrup', '0014', '1552392324.jpg'),
(65, 'afa', 78, 'fasdf', 77, 'medicine', '', 'syrup', '0013', '1552398153.jpg'),
(66, 'Napa', 3, 'For Fever', 44, 'paracetamol', '', 'teblets', '0014', '1552499694.jpg'),
(67, 'Calbo d', 60, 'for bone pain', 9, 'medicine', '', 'capsules', '0015', '1552500925.jpg'),
(68, 'eye drop', 21, 'allergies, the common cold, or the flu', 5, 'medicine', '', 'capsules', '0012', '1552503354.jpg'),
(69, 'Cloramin', 21, 'allergies, the common cold, or the flu', 5, 'medicine', '', 'capsules', '0012', '1552503723.jpg'),
(70, 'stayfree', 120, 'periods and Minstration', 20, 'medicine', 'other', 'peds', '001', '1552508440.jpg'),
(71, 'Drypers XL', 520, 'baby napkin', 8, 'medicine', 'other', 'drypers', '0015', '1552509969.jpg'),
(72, 'Dettol', 45, 'Antiseptic', 5, 'medicine', '', 'others', '0015', '1552719801.jpg'),
(73, 'Napa Extend', 2, 'For feaver', 60, 'paracetamol', '500mg', 'teblets', '0046', '1553182983.jpg'),
(74, 'Cloramin', 21, 'allergies, the common cold, or the flu', 40, 'paracetamol', '60mg', 'syrup', '1234', '1554564651.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `firstName` varchar(25) NOT NULL,
  `lastName` varchar(25) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `address` varchar(120) NOT NULL,
  `password` varchar(100) NOT NULL,
  `confirmCode` varchar(10) NOT NULL,
  `activation` varchar(10) NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `firstName`, `lastName`, `email`, `mobile`, `address`, `password`, `confirmCode`, `activation`) VALUES
(9, 'Borsha', 'Tanjina', 'Tanjina@gmail.com', '01578399283', 'Dhaka, Bangladesh', '81dc9bdb52d04dc20036dbd8313ed055', '217576', 'yes'),
(10, 'Trisha', 'Rehman', 'trisha@gmail.com', '01923457834', 'Mirpur 2, Dhaka', '5af7a513a7c48f6cc97253254b29509b', '0', 'yes'),
(11, 'Akhi', 'Alam', 'akhi@gmail.com', '01678293748', 'Saver, Dhaka', 'ca52febd8be7c4480ae90cdae8438a03', '0', 'yes'),
(12, 'Sima', 'Ahmed', 'sima@gmail.com', '01627021788', 'dhaka,purbo rajabajar', '81dc9bdb52d04dc20036dbd8313ed055', '263899', 'no'),
(13, 'Sakil', 'Khan', 'sakil@gmail.com', '01750949777', 'rajabazar,jame moshid,92/2', '81dc9bdb52d04dc20036dbd8313ed055', '0', 'yes'),
(14, 'Jia', 'Ahmed', 'jia@gmail.com', '01234567897', 'dhaka..road..pue', '81dc9bdb52d04dc20036dbd8313ed055', '0', 'yes'),
(15, 'Maria', 'Ritu', 'maria@gmail.com', '0174122258', 'purbo rajabazar,dhaka,92/2', 'd93591bdf7860e1e4ee2fca799911215', '0', 'yes'),
(16, 'Nur', 'Ahmed', 'nur@gmail.com', '01627021788', 'dhaka,purbo rajabajar', '81dc9bdb52d04dc20036dbd8313ed055', '0', 'yes'),
(17, 'Gia', 'Ali', 'gia@gmail.com', '01627021788', 'uttara', 'e10adc3949ba59abbe56e057f20f883e', '0', 'yes'),
(18, 'Nur E', 'Mohsin', 'nurr@gmail.com', '01627021788', 'purbo rajabazar,dhaka,92/2', '81dc9bdb52d04dc20036dbd8313ed055', '0', 'yes'),
(19, 'Samim', 'Ahmed', 'samim@gmail.com', '01627021788', 'dhaka,purbo rajabajar', '81dc9bdb52d04dc20036dbd8313ed055', '0', 'yes'),
(20, 'Israt', 'Jahan', 'israt@gmail.com', '01718911141', 'rosa,east razabazrar hostel.', 'e10adc3949ba59abbe56e057f20f883e', '0', 'yes'),
(21, 'Sakil', 'Islam', 'saakil@gmail.com', '01627021788', 'Purborazabazar jame moshjid', '98427fd4fe1dd535d4492e05f3a25236', '0', 'yes'),
(22, 'Ratri', 'Ahmed', 'ratri@gmail.com', '01627021788', 'purbo rajabazar,dhaka,92/2', '81dc9bdb52d04dc20036dbd8313ed055', '0', 'yes'),
(23, 'Tuli', 'Ahmed', 'tuli@gmail.com', '01627021788', 'rajabazar,jame moshid,92/2', '81dc9bdb52d04dc20036dbd8313ed055', '0', 'yes'),
(24, 'Resu', 'Ahmed', 'resu@gmail.com', '01627021788', 'purbo rajabazar,dhaka,92/2', '81dc9bdb52d04dc20036dbd8313ed055', '0', 'yes'),
(25, 'Tina', 'Ahmed', 'tina@gmail.com', '01627021788', 'purbo rajabazar,dhaka,92/2', '81dc9bdb52d04dc20036dbd8313ed055', '0', 'yes'),
(26, 'Lima', 'Ahmed', 'lima@gmail.com', '01627021788', 'purbo rajabazar,dhaka,92/2', '81dc9bdb52d04dc20036dbd8313ed055', '0', 'yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
