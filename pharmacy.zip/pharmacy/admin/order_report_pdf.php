<?php include ( "../inc/connect.inc.php" ); ?>
<?php 
ob_start();
session_start();
if (!isset($_SESSION['admin_login'])) {
	header("location: login.php");
	$user = "";
}
else {
	if (isset($_REQUEST['eoid'])) {
	
		$eoid = mysql_real_escape_string($_REQUEST['eoid']);
		$getposts5 = mysql_query("SELECT * FROM orders WHERE id='$eoid'") or die(mysql_error());
			if (mysql_num_rows($getposts5)){

			}else {
				header('location: index.php');
			}
	}else {
		header('location: index.php');
	}
	
	$user = $_SESSION['admin_login'];
	$result = mysql_query("SELECT * FROM admin WHERE id='$user'");
		$get_user_email = mysql_fetch_assoc($result);
			$uname_db = $get_user_email['firstName'];
			$utype_db=$get_user_email['type'];
			if($utype_db == 'staff'){
				header("location: login.php");
			}
}



require_once '../dompdf/autoload.inc.php';
use Dompdf\Dompdf;
$sales_report = new Dompdf();
$page = file_get_contents("order_report_pdf.php");


$output = '
		<html>
		<head>
			<title>Pharmacy Management System</title>
			<style>
			body{
				padding: 15px;
				font-size: 15px;
			}
			table {
			  font-family: arial, sans-serif;
			  border-collapse: collapse;
			  width: 100%;
			}

			td, th {
			  border: 1px solid #dddddd;
			  text-align: left;
			  padding: 8px;
			}

			tr:nth-child(even) {
			  background-color: #dddddd;
			}
			</style>
		</head>
		<body>
				';

$result1 = mysql_query("SELECT * FROM orders WHERE id='$eoid'");
		$get_order_info = mysql_fetch_assoc($result1);
			$eouid = $get_order_info['uid'];
			$eopid = $get_order_info['pid'];
			$eoquantity = $get_order_info['quantity'];
			$eoplace = $get_order_info['oplace'];
			$eomobile = $get_order_info['mobile'];
			$eodstatus = $get_order_info['dstatus'];
			$eodustatus = ucwords($get_order_info['dstatus']);
			$eodate = $get_order_info['odate'];
			$eddate = $get_order_info['ddate'];

			$result2 = mysql_query("SELECT * FROM user WHERE id='$eouid'");
			$get_order_info2 = mysql_fetch_assoc($result2);
			$euname = $get_order_info2['firstName'];
			$euemail = $get_order_info2['email'];
			$eumobile = $get_order_info2['mobile'];


$getposts = mysql_query("SELECT * FROM products WHERE id ='$eopid'") or die(mysql_error());
					if (mysql_num_rows($getposts)) {
						$row = mysql_fetch_assoc($getposts);
						$id = $row['id'];
						$pName = $row['pName'];
						$price = $row['price'];
						$description = $row['description'];
						$picture = $row['picture'];
						$item = $row['item'];
						$category = $row['category'];
						$available =$row['available'];
					}	


$output .= '
			<h1 style="text-align: center;">Invoice</h1>
		<header>
			<address contenteditable>
				<h3>From</h3>
				<p>Afsana</p>
				<p>Online Medicine Shop</p>
			</address>
		</header>
		<br>
		<article>
			<h3>Recipient</h3>
			<address contenteditable>
				<p>'.$euname.'</p>
				<p>'.$eoplace.'</p>
				<p>'.$eumobile.'</p>
			</address>
			<br>
			<table class="meta">
				<tr>
					<th><span contenteditable>Invoice #</span></th>
					<td><span contenteditable>'.$eoid.'</span></td>
				</tr>
				<tr>
					<th><span contenteditable>Date</span></th>
					<td><span contenteditable>'.$eodate.'</span></td>
				</tr>
				<tr>
					<th><span contenteditable>Amount Due</span></th>
					<td><span id="prefix" contenteditable>Tk</span><span>'.$price*$eoquantity.'</span></td>
				</tr>
			</table>
			<table class="inventory">
				<thead>
					<tr>
						<th><span contenteditable>Item</span></th>
						<th><span contenteditable>Description</span></th>
						<th><span contenteditable>Rate</span></th>
						<th><span contenteditable>Quantity</span></th>
						<th><span contenteditable>Price</span></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><span contenteditable>'.$pName.'</span></td>
						<td><span contenteditable>'.$description.'</span></td>
						<td><span data-prefix>Tk</span><span contenteditable>'.$price.'</span></td>
						<td><span contenteditable>'.$eoquantity.'</span></td>
						<td><span data-prefix>Tk</span><span>'.$price*$eoquantity.'</span></td>
					</tr>
				</tbody>
			</table>
			<table class="balance">
				<tr>
					<th><span contenteditable>Total</span></th>
					<td><span data-prefix>Tk</span><span>'.$price*$eoquantity.'</span></td>
				</tr>
				<tr>
					<th><span contenteditable>Amount Paid</span></th>
					<td><span data-prefix>Tk</span><span contenteditable>0.00</span></td>
				</tr>
				<tr>
					<th><span contenteditable>Balance Due</span></th>
					<td><span data-prefix>Tk</span><span>'.$price*$eoquantity.'</span></td>
				</tr>
			</table>
		</article>

		</body></html>';

$sales_report->loadHtml($output);
$sales_report->setPaper('A2', 'landscope');
$sales_report->render();
$sales_report->stream("Sales_Report", array("Attachment"=>0));

?>