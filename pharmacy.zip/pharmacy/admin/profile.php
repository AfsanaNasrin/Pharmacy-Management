<?php include ( "../inc/connect.inc.php" ); ?>
<?php 
ob_start();
session_start();
if (!isset($_SESSION['admin_login'])) {
	header("location: login.php");
	$user = "";
	$utype = "";
}
else {
	$user = $_SESSION['admin_login'];
	$utype = $_SESSION['admin_type'];
	$result = mysql_query("SELECT * FROM admin WHERE id='$user'");
		$get_user_email = mysql_fetch_assoc($result);
			$uname_db = $get_user_email['firstName'];
			$ulname_db = $get_user_email['lastName'];
			$email = $get_user_email['email'];
			$mobile = $get_user_email['mobile'];
			$address = $get_user_email['address'];
			$type = $get_user_email['type'];
}


$search_value = "";
?>


<!doctype html>
<html>
	<head>
		<title>Pharmacy</title>
		<link rel="stylesheet" type="text/css" href="../css/style.css">
	</head>
	<body class="home-welcome-text" style="background-image: url(../image/img3.jpg); background-repeat: no-repeat;background-position: center;background-size: cover;">
		<div class="homepageheader">
			<div class="signinButton loginButton">
				<div class="uiloginbutton signinButton loginButton" style="margin-right: 40px;">
					<?php 
						if ($user!="") {
							echo '<a style="text-decoration: none; color: #fff;" href="logout.php">LOG OUT</a>';
						}
					 ?>
					
				</div>
				<div class="uiloginbutton signinButton loginButton">
					<?php 
						if ($user!="") {
							echo '<a style="text-decoration: none; color: #fff;" href="profile.php">Hi '.$uname_db.'</a>';
						}
						else {
							echo '<a style="text-decoration: none; color: #fff;" href="login.php">LOG IN</a>';
						}
					 ?>
				</div>
			</div>
			<div style="float: left; margin: 5px 0px 0px 23px;">
				<a href="index.php">
					<img style=" height: 75px; width: 130px;" src="../image/logo2.jpg">
				</a>
			</div>
			<div id="srcheader">
				<form id="newsearch" method="get" action="search.php">
				        <?php 
				        	echo '<input type="text" class="srctextinput" name="keywords" size="21" maxlength="120"  placeholder="Search Here..." value="'.$search_value.'"><input type="submit" value="search" class="srcbutton" >';
				         ?>
				</form>
			<div class="srcclear"></div>
			</div>
		</div>
		
		<?php include ( "headermenu.inc.php" ); ?>
		<div style="width: 50%;color: #067165;background-color: #ddd;padding: 10px;">
					<div style="">
						<h3 style="font-size: 25px;">Name: <?php echo $uname_db." ". $ulname_db; ?></h3><hr>
						<h3 style="padding: 20px 0 0 0; font-size: 20px;">Email: <?php echo $email; ?></h3><hr>
						<h3 style="padding: 20px 0 0 0; font-size: 20px;">Mobile: <?php echo $mobile; ?></h3><hr>
						<h3 style="padding: 20px 0 0 0; font-size: 20px;">Address: <?php echo $address; ?></h3><hr>
						<h3 style="padding: 20px 0 0 0; font-size: 20px;">Type: <?php echo $type; ?></h3><hr>

						

					</div>
				</div>
	</body>
</html>
