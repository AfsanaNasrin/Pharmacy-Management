<div class="categolis">
		<table>
		<?php
			if ($_SESSION['admin_type'] == 'admin') {
				echo'
					<tr>
						<th><a href="newadmin.php" style="text-decoration: none;color: #ddd;padding: 4px 12px;background-color: #24bfae;border-radius: 12px;">Create New Pharmacist</a></th>
						<th><a href="all_admin.php" style="text-decoration: none;color: #ddd;padding: 4px 12px;background-color: #24bfae;border-radius: 12px;">All Employees</a></th>
					</tr>
				';
			}else if ($_SESSION['admin_type'] == 'pharmacist') {
				echo'
					<tr>
						<th><a href="index.php" style="text-decoration: none;color: #fff;padding: 4px 12px;background-color: #c7587e;border-radius: 12px;">Home</a></th>
						<th><a href="addproduct.php" style="text-decoration: none;color: #ddd;padding: 4px 12px;background-color: #c7587e;border-radius: 12px;">Add Medicines</a></th>
						<th><a href="allproducts.php" style="text-decoration: none;color: #ddd;padding: 4px 12px;background-color: #c7587e;border-radius: 12px;">All Medicines</a></th>
						<th><a href="orders.php" style="text-decoration: none;color: #ddd;padding: 4px 12px;background-color: #c7587e;border-radius: 12px;">Orders</a></th>
						<th><a href="report.php" style="text-decoration: none;color: #ddd;padding: 4px 12px;background-color: #c7587e;border-radius: 12px;">Reports</a></th>
					    <th><a href="DeliveryRecords.php" style="text-decoration: none;color:  #ddd;padding: 4px 12px;background-color: #c7587e;border-radius: 12px;">DeliveryRecords</a></th>
						<th><a href="sales_report_pdf.php" style="text-decoration: none;color: black;padding: 4px 12px;background-color: #c7587e;border-radius: 12px;">Total Sales</a></th>
					</tr>
				';
			}
		?>
		</table>
	</div>